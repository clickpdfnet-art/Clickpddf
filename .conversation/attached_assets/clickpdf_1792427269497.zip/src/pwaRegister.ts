export function registerServiceWorker() {
  if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
    if (!import.meta.env.PROD) {
      // In development / preview, ensure service workers do not cache stale content
      navigator.serviceWorker.getRegistrations().then((registrations) => {
        for (const registration of registrations) {
          registration.unregister();
        }
      });
      return;
    }

    window.addEventListener('load', () => {
      navigator.serviceWorker
        .register('/sw.js')
        .then((registration) => {
          console.log('[ClickPDF] ServiceWorker registered with online enforcement:', registration.scope);
        })
        .catch((error) => {
          console.warn('[ClickPDF] ServiceWorker registration failed:', error);
        });
    });
  }
}
