import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

interface SimpleToolSeo {
  toolId: string;
  slug: string;
  title: string;
  description: string;
}

// 24 Core & Office PDF Tools registry with canonical slugs
const TOOLS_METADATA: SimpleToolSeo[] = [
  { toolId: 'merge', slug: 'merge-pdf', title: 'Merge PDF Online', description: 'Combine multiple PDF files into one clean document with drag-and-drop reordering.' },
  { toolId: 'split', slug: 'split-pdf', title: 'Split PDF Online', description: 'Separate PDF pages, extract page ranges, or burst all pages into individual files.' },
  { toolId: 'compress', slug: 'compress-pdf', title: 'Compress PDF Online', description: 'Reduce PDF file size in browser memory while preserving high visual quality.' },
  { toolId: 'jpg-to-pdf', slug: 'image-to-pdf', title: 'Image to PDF Converter', description: 'Convert JPG, PNG, and WebP images into a single high-quality PDF portfolio.' },
  { toolId: 'rotate', slug: 'rotate-pdf', title: 'Rotate PDF Online', description: 'Rotate PDF pages permanently 90, 180, or 270 degrees in your browser.' },
  { toolId: 'watermark', slug: 'watermark-pdf', title: 'Watermark PDF Online', description: 'Stamp customizable text or logo watermarks diagonally across PDF pages.' },
  { toolId: 'page-numbers', slug: 'page-numbers-pdf', title: 'Add Page Numbers to PDF', description: 'Insert sequential header or footer page numbers into your documents.' },
  { toolId: 'organize', slug: 'organize-pdf', title: 'Organize PDF Pages', description: 'Visually rearrange, duplicate, and delete pages inside your PDF documents.' },
  { toolId: 'protect', slug: 'protect-pdf', title: 'Password Protect PDF', description: 'Encrypt documents with zero-knowledge AES-256 Web Crypto in your browser.' },
  { toolId: 'unlock', slug: 'unlock-pdf', title: 'Unlock Password Protected PDF', description: 'Decrypt and remove passwords from PDFs in browser memory.' },
  { toolId: 'extract-images', slug: 'extract-images-from-pdf', title: 'Extract Images from PDF', description: 'Extract all embedded photos and raster graphics from PDF files in full resolution.' },
  { toolId: 'metadata', slug: 'pdf-metadata', title: 'PDF Metadata & Inspector', description: 'Inspect embedded metadata, author details, fonts, and sanitize sensitive tags.' },
  { toolId: 'crop', slug: 'crop-pdf', title: 'Crop PDF Margins', description: 'Trim page margins and adjust visible document canvas borders.' },
  { toolId: 'compare', slug: 'compare-pdf', title: 'Compare PDF Documents', description: 'Highlight visual and textual differences between two versions of a document.' },
  { toolId: 'repair', slug: 'repair-pdf', title: 'Repair Corrupted PDF', description: 'Reconstruct broken cross-reference tables and recover damaged PDF files.' },
  { toolId: 'flatten', slug: 'flatten-pdf', title: 'Flatten PDF Form Fields', description: 'Convert interactive form fields and annotations into static document content.' },
  { toolId: 'grayscale', slug: 'grayscale-pdf', title: 'Convert PDF to Grayscale', description: 'Transform full-color PDFs into crisp black and white documents for archival.' },
  { toolId: 'pdf-to-txt', slug: 'pdf-to-text', title: 'PDF to Text Converter', description: 'Extract clean, raw text and characters from PDF files without cloud uploads.' },
  // Office suite converters
  { toolId: 'pdf-to-word', slug: 'pdf-to-word', title: 'PDF to Word Converter', description: 'Convert PDF documents into editable Microsoft Word (.docx) files in your browser.' },
  { toolId: 'pdf-to-excel', slug: 'pdf-to-excel', title: 'PDF to Excel Converter', description: 'Extract tabular PDF rows into structured Microsoft Excel (.xlsx) spreadsheets.' },
  { toolId: 'pdf-to-powerpoint', slug: 'pdf-to-powerpoint', title: 'PDF to PowerPoint Converter', description: 'Convert PDF slides into presentation-ready Microsoft PowerPoint (.pptx) decks.' },
  { toolId: 'word-to-pdf', slug: 'word-to-pdf', title: 'Word to PDF Converter', description: 'Convert Word DOCX documents into clean, standard PDF files entirely in-browser.' },
  { toolId: 'excel-to-pdf', slug: 'excel-to-pdf', title: 'Excel to PDF Converter', description: 'Convert Excel spreadsheets and worksheets into printable PDF documents.' },
  { toolId: 'powerpoint-to-pdf', slug: 'powerpoint-to-pdf', title: 'PowerPoint to PDF Converter', description: 'Convert PowerPoint slide presentations into portable, universally viewable PDF files.' }
];

interface SimpleBlogPost {
  slug: string;
  title: string;
  date: string;
  summary: string;
  coverImage?: string;
}

function parseMarkdownFrontmatter(content: string, filename: string): SimpleBlogPost {
  const trimmed = content.trim();
  let frontmatter: Record<string, string> = {};

  if (trimmed.startsWith('---')) {
    const match = trimmed.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n([\s\S]*)$/);
    if (match) {
      const rawYaml = match[1];
      rawYaml.split(/\r?\n/).forEach((line) => {
        const colonIdx = line.indexOf(':');
        if (colonIdx > 0) {
          const key = line.substring(0, colonIdx).trim().toLowerCase();
          let val = line.substring(colonIdx + 1).trim();
          if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
            val = val.substring(1, val.length - 1);
          }
          frontmatter[key] = val;
        }
      });
    }
  }

  const baseSlug = frontmatter['slug'] || path.basename(filename, '.md');
  return {
    slug: baseSlug,
    title: frontmatter['title'] || baseSlug.replace(/-/g, ' '),
    date: frontmatter['date'] || new Date().toISOString().split('T')[0],
    summary: frontmatter['summary'] || frontmatter['excerpt'] || '',
    coverImage: frontmatter['coverimage'] || frontmatter['image']
  };
}

function scanBlogsFolder(): SimpleBlogPost[] {
  const blogsDir = path.join(rootDir, 'src', 'blogs');
  if (!fs.existsSync(blogsDir)) return [];

  const files = fs.readdirSync(blogsDir).filter(f => f.endsWith('.md'));
  const posts: SimpleBlogPost[] = [];

  for (const file of files) {
    try {
      const fullPath = path.join(blogsDir, file);
      const raw = fs.readFileSync(fullPath, 'utf-8');
      const post = parseMarkdownFrontmatter(raw, file);
      posts.push(post);
    } catch (err) {
      console.warn(`Failed reading blog ${file}:`, err);
    }
  }

  return posts;
}

function escapeXml(unsafe: string): string {
  return (unsafe || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

export function generateSitemapAndRobots(baseUrl = 'https://clickpdf.net') {
  const today = new Date().toISOString().split('T')[0];
  const blogs = scanBlogsFolder();

  const xmlEntries: string[] = [];

  // 1. Homepage
  xmlEntries.push(`  <url>
    <loc>${baseUrl}/</loc>
    <lastmod>${today}</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>`);

  // 2. All 24 PDF Tools
  TOOLS_METADATA.forEach((tool) => {
    const isCore = ['merge-pdf', 'split-pdf', 'compress-pdf', 'image-to-pdf', 'rotate-pdf', 'pdf-to-word'].includes(tool.slug);
    xmlEntries.push(`  <url>
    <loc>${baseUrl}/tools/${tool.slug}</loc>
    <lastmod>${today}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>${isCore ? '0.9' : '0.8'}</priority>
  </url>`);
  });

  // 3. Blog Hub
  xmlEntries.push(`  <url>
    <loc>${baseUrl}/blog</loc>
    <lastmod>${today}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.8</priority>
  </url>`);

  // 4. All Blog Posts (auto-scanned from src/blogs/*.md)
  blogs.forEach((post) => {
    let imageTag = '';
    if (post.coverImage) {
      imageTag = `\n    <image:image>\n      <image:loc>${escapeXml(post.coverImage)}</image:loc>\n      <image:title>${escapeXml(post.title)}</image:title>\n    </image:image>`;
    }

    xmlEntries.push(`  <url>
    <loc>${baseUrl}/blog/${encodeURIComponent(post.slug)}</loc>
    <lastmod>${today}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>${imageTag}
  </url>`);
  });

  // Assemble full sitemap.xml
  const totalUrls = xmlEntries.length;
  const sitemapXml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
        http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
<!-- Generated dynamically by ClickPDF Sitemap Engine -->
<!-- Total URLs: ${totalUrls} (1 Core + ${TOOLS_METADATA.length} PDF Tools + 1 Blog Hub + ${blogs.length} Blog Posts) -->
${xmlEntries.join('\n')}
</urlset>
`;

  // Assemble robots.txt
  const robotsTxt = `# ClickPDF Robots.txt - In-Browser Privacy Utilities
User-agent: *
Allow: /
Allow: /tools/*
Allow: /blog/*
Allow: /blog
Allow: /?tool=*
Allow: /?view=*
Allow: /?article=*

# Dynamic XML Sitemap
Sitemap: ${baseUrl}/sitemap.xml
`;

  // Write to public/
  const publicDir = path.join(rootDir, 'public');
  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }

  const sitemapPath = path.join(publicDir, 'sitemap.xml');
  const robotsPath = path.join(publicDir, 'robots.txt');

  fs.writeFileSync(sitemapPath, sitemapXml, 'utf-8');
  fs.writeFileSync(robotsPath, robotsTxt, 'utf-8');

  console.log(`[ClickPDF Sitemap Generator] Successfully generated:`);
  console.log(`  -> ${sitemapPath} (${totalUrls} URLs: ${TOOLS_METADATA.length} tools, ${blogs.length} blogs)`);
  console.log(`  -> ${robotsPath}`);

  return { totalUrls, toolsCount: TOOLS_METADATA.length, blogsCount: blogs.length };
}

// Run directly if invoked via node/tsx
generateSitemapAndRobots();
